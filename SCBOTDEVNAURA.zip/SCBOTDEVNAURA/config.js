import { watchFile, unwatchFile } from 'fs'
import chalk from 'chalk'
import { fileURLToPath } from 'url'

global.owner = [
  ['6283196514469', 'naurayusniar, true],
  ['6283196514469']
] // nomor owner

global.mods = ['6283196514469'] 
global.prems = ['6283196514469', '6281545503781']
global.APIs = { // API Prefix
  // name: 'https://website' 
  nrtm: 'https://fg-nrtm.ddns.net',
  lann: 'https://api.betabotz.eu.org'
}
global.APIKeys = { // APIKey Here
  // 'https://website': 'apikey'
  'https://api.betabotz.eu.org': 'DAFTAR / ISI APIKEY LU'
}

// daftar di sini https://api.betabotz.eu.org
global.lann = 'DAFTAR / ISI APIKEY LU'

// setting limit user
global.limit = 69

// Sticker WM
global.packname = 'Naura' 
global.author = '@naurayusniar' 
//--info NS [ NANS ]
global.NSnama = 'NAURA SIMPLE BOT MD'
global.NSig = 'https://www.instagram.com/naurayusniar' 
global.NSgc = 'https://whatsapp.com/channel/0029VaAji75KgsNxNzZV6j2L'
global.NSthumb = 'https://telegra.ph/file/5ab886978e8e6ffa81805.jpg'

global.wait = '*⌛ _Loading..._*\n*▰▰▰▱▱▱▱▱*'
global.eror = 'Error, Kesalahan tidak terduga'
global.rwait = '⌛'
global.dmoji = '🤭'
global.done = '✅'
global.error = '❌' 
global.xmoji = '🔥' 

global.multiplier = 69 
global.maxwarn = '2' // max warning

let file = fileURLToPath(import.meta.url)
watchFile(file, () => {
  unwatchFile(file)
  console.log(chalk.redBright("Update 'config.js'"))
  import(`${file}?update=${Date.now()}`)
})
